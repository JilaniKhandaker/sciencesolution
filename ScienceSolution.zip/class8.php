<?php

$pages="class8";
include './index.php';
