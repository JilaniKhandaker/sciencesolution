<?php

$pages = 'article';
include './admin_master.php';