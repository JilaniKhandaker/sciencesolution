<?php

$pages = "approve_student";
include './admin_master.php';

