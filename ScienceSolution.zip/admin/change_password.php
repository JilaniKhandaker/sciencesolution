<?php
$pages='change_password';
include './admin_master.php';