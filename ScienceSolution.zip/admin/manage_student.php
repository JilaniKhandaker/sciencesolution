<?php

$pages= "manage_student";
include './admin_master.php';