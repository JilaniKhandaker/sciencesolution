<?php

$pages = 'suggestion';
include './admin_master.php';