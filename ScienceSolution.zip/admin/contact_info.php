<?php

$pages = 'contact_info';
include './admin_master.php';