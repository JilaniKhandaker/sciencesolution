<?php

$pages = 'notice';
include './admin_master.php';