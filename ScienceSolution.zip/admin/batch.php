<?php

$pages="batch";
include './admin_master.php';