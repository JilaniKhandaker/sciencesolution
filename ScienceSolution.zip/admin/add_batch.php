<?php

$pages = "add_batch";
include './admin_master.php';

