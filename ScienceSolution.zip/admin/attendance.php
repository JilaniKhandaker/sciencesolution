<?php

$pages= "attendance";
include './admin_master.php';