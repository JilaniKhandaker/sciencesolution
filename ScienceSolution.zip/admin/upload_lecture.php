<?php

$pages = 'upload_lecture';
include './admin_master.php';