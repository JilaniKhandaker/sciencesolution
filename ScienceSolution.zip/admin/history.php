<?php

$pages = 'history';
include './admin_master.php';