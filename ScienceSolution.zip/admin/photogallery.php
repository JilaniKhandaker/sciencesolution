<?php

$pages = 'photo';
include './admin_master.php';