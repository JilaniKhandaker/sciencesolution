<?php
$pages ="payment";
include './admin_master.php';