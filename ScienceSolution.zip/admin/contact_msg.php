<?php

$pages = 'contact_msg';
include './admin_master.php';