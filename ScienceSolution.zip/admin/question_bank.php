<?php

$pages = 'question_bank';
include './admin_master.php';