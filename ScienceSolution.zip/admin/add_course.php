<?php

$pages ="add_course";
include './admin_master.php';
