<?php

$pages = "advertise";
include './admin_master.php';

