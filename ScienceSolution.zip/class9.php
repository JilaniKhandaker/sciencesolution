<?php

$pages="class9";
include './index.php';
