<!-- Header -->
	<header id="head">
		<div class="container">
			<div class="row">
				<h1 class="lead">General Math, Higher Math,<br/> Physics, Chemistry, ICT</h1>
				<p class="tagline">We are here to make u confident on Science</p>
                                <p><a  href="article.php" class="btn btn-default btn-lg" role="button">Articles  </a>
                                    <a href="question_bank.php" class="btn btn-action btn-lg" role="button">Question Bank</a>
                                   <a  href="lecture.php" class="btn btn-default btn-lg" role="button">Lectures </a>
                                </p>
			</div>
		</div>
	</header>
	<!-- /Header -->
        <!-- Intro -->
	<div class="container text-center">
		<br> <br>
		<h2 class="thin">The best place to tell people why they are here</h2>
		<p class="text-muted">
			The difference between involvement and commitment is like an eggs-and-ham breakfast:<br> 
			the chicken was involved; the pig was committed.
		</p>
	</div>
	<!-- /Intro-->
		
	
       
        
        
	
	<!-- Social links. @TODO: replace by link/instructions in template -->
	<section id="social">
		<div class="container">
			<div class="wrapper clearfix">
				<!-- AddThis Button BEGIN -->
				<div class="addthis_toolbox addthis_default_style">
				<a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
				<a class="addthis_button_tweet"></a>
				<a class="addthis_button_linkedin_counter"></a>
				<a class="addthis_button_google_plusone" g:plusone:size="medium"></a>
				</div>
				<!-- AddThis Button END -->
			</div>
		</div>
	</section>