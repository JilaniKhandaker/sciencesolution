<?php

$pages="student_info";
include './index.php';
