<?php

$pages="signup";
include './index.php';