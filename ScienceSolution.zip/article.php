<?php

$pages = 'article';
include './index.php';