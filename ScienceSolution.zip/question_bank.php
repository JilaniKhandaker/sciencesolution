<?php

$pages = 'question_bank';
include './index.php';