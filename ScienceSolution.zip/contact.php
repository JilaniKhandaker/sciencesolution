<?php

$pages ="contact";
include './index.php';