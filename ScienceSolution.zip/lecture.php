<?php

$pages = 'lecture';
include './index.php';