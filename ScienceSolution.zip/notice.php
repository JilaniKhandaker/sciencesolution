<?php

$pages="notice_page";
include './index.php';