<?php

$pages="class10";
include './index.php';
