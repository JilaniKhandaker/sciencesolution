<?php
$pages="result_page";
include './index.php';