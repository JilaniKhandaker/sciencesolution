<?php

$pages="class11";
include './index.php';
