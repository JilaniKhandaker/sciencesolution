<?php
$pages="photo_gallery";
include './index.php';